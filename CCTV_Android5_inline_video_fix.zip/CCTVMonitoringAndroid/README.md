# CCTV Monitoring — Android 5.0+ (API 21+)

Project Android berbasis WebView untuk 21 kamera HLS sesuai konfigurasi yang diberikan.

## Kompatibilitas
- Minimum Android 5.0 / API 21 (termasuk Android 5.1).
- Target SDK 28 agar akses HTTP lokal/server tetap diizinkan sesuai konfigurasi manifest.
- Java 17, Gradle 8.7, Android Gradle Plugin mengikuti konfigurasi project.
- Pemutaran utama menggunakan HLS melalui hls.js. URL WebRTC disimpan dalam data konfigurasi tetapi belum dipakai sebagai jalur playback.

## Build APK release bertanda tangan melalui GitHub Actions
1. Buat repository GitHub dan upload seluruh isi folder project ini.
2. Pada repository buka **Settings → Secrets and variables → Actions → New repository secret**.
3. Tambahkan empat secret berikut:
   - `ANDROID_KEYSTORE_BASE64`: isi file keystore `.jks` dalam format Base64 satu baris.
   - `ANDROID_KEYSTORE_PASSWORD`: password keystore.
   - `ANDROID_KEY_ALIAS`: alias key.
   - `ANDROID_KEY_PASSWORD`: password key.
4. Jalankan **Actions → Build CCTV Monitoring Android 5 Signed Release APK → Run workflow**.
5. Setelah sukses, buka hasil workflow dan unduh artifact `CCTV-Monitoring-Android5-release-signed`.
6. Ekstrak ZIP artifact; file APK bernama `app-release.apk`.

## Catatan penting
- Workflow sengaja gagal jika secret signing belum diisi; tidak akan menghasilkan release yang diklaim signed tanpa signature.
- Simpan backup keystore dan password. APK update harus ditandatangani dengan key yang sama agar dapat memasang pembaruan di atas versi sebelumnya.
- Android 5 membutuhkan Android System WebView/Chrome yang cukup baru dan mendukung Media Source Extensions agar hls.js dapat memutar HLS. Jika stream gagal, uji URL `.m3u8` dari perangkat dan perbarui WebView.
- Server memakai HTTP publik. Gunakan jaringan tepercaya; untuk penggunaan produksi, lebih aman menambahkan autentikasi dan HTTPS.
